package edu.neumont;

public class Pass {
    int randNum;
    int tries;
}
