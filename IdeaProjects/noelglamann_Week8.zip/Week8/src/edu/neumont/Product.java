package edu.neumont;

public class Product{
    private String name;
    private double price;
    //8-1 (Final Variables)
    private final static double TAX = 0.085;

    public Product() {
    }
    public Product(String name) {
        this.name = name;
    }
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }

    //7-3 (Method Overloading)
    public void setPrice(double price){
        this.price = price;
    }
    public void setPrice(int price){
        this.price = price;
    }
    public void setPrice(String price){
        //8-3 (Exceptions)
        try{
            this.price = Double.parseDouble(price);
        }catch (NumberFormatException e){
            System.out.println("Number Format Issue " + e.getMessage());
        }catch (Exception e){
            System.out.println("exception: " + e.getMessage());
        }
    }

    private double getTax() {
        return price * TAX;
    }

    public double getTotal(){
        return price + getTax();
    }

    public void display(){
        System.out.println("name: " + name);
        System.out.println("price: $" + price);
    }
}
