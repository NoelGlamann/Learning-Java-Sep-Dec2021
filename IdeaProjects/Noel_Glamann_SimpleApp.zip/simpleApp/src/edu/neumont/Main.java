/*Noel Glamann
Nov. 1, 2021
Yahtzee App
*/

package edu.neumont;

public class Main {

    public static void main(String[] args) {
        Game game = new Game();
    }

}
