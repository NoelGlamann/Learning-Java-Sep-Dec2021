package com.example.iterationexercise;

import java.util.ArrayList;
import java.util.Random;

public class Numbers {
    Random random = new Random();

    public int getRandInt(){
        return random.nextInt(100);
    }

}
